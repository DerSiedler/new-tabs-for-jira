(() => {
  'use strict';
  if (window.__NEW_TABS_JIRA_DC_V171__) return;
  window.__NEW_TABS_JIRA_DC_V171__ = true;

  const CARD_SELECTOR = '.ghx-issue[data-issue-key]';
  const IGNORE_SELECTOR = [
    '.m-sortable-trigger',
    '.js-draggable-trigger',
    'button',
    'input',
    'textarea',
    'select',
    'option',
    '[contenteditable="true"]',
    '[role="menuitem"]'
  ].join(',');

  const DETAIL_PANEL_SELECTORS = [
    '#ghx-detail-view',
    '.ghx-detail-view',
    '#ghx-detail-contents',
    '.ghx-detail-contents',
    '[data-testid*="detail-view" i]',
    '[data-testid*="issue-detail" i]',
    '[aria-label*="detail view" i]',
    '[aria-label*="Detailansicht" i]'
  ];

  const SHOW_DETAIL_LABELS = [
    'show detail view',
    'show issue detail view',
    'detailansicht anzeigen',
    'vorgangsdetailansicht anzeigen'
  ];

  const HIDE_DETAIL_LABELS = [
    'hide detail view',
    'hide issue detail view',
    'detailansicht ausblenden',
    'vorgangsdetailansicht ausblenden'
  ];

  // A genuine card click is brief and almost motionless. Jira may still emit a
  // click after a tentative drag, so the complete pointer gesture is tracked.
  const MOVE_THRESHOLD_PX = 3;
  const HOLD_THRESHOLD_MS = 280;

  let enabled = true;
  let gesture = null;
  let lastGesture = null;
  let detailViewState = {
    status: 'unknown',
    source: 'none',
    checkedAt: 0
  };
  let detectionTimer = null;

  chrome.storage.local.get({ enabled: true }).then(result => {
    enabled = result.enabled !== false;
  });

  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === 'local' && changes.enabled) {
      enabled = changes.enabled.newValue !== false;
    }
  });

  function getCard(node) {
    return node instanceof Element ? node.closest(CARD_SELECTOR) : null;
  }

  function getIssueUrl(card) {
    const link = card.querySelector('a[href*="/browse/"]');
    if (link) return new URL(link.getAttribute('href'), location.href).href;

    const key = card.dataset.issueKey;
    return key ? new URL(`/browse/${encodeURIComponent(key)}`, location.origin).href : null;
  }

  function isVisiblyRendered(element) {
    if (!(element instanceof Element)) return false;
    const style = getComputedStyle(element);
    if (style.display === 'none' || style.visibility === 'hidden' || Number(style.opacity) === 0) {
      return false;
    }
    const rect = element.getBoundingClientRect();
    return rect.width >= 180 && rect.height >= 100;
  }

  function normalizedLabel(element) {
    return [
      element.textContent,
      element.getAttribute('aria-label'),
      element.getAttribute('title')
    ]
      .filter(Boolean)
      .join(' ')
      .replace(/\s+/g, ' ')
      .trim()
      .toLowerCase();
  }

  function findActionLabelState() {
    const candidates = document.querySelectorAll(
      'button, a, [role="menuitem"], [role="button"], [aria-label], [title]'
    );

    for (const element of candidates) {
      const label = normalizedLabel(element);
      if (!label) continue;

      if (SHOW_DETAIL_LABELS.some(phrase => label.includes(phrase))) {
        return { status: 'hidden', source: 'menu-label' };
      }
      if (HIDE_DETAIL_LABELS.some(phrase => label.includes(phrase))) {
        return { status: 'visible', source: 'menu-label' };
      }
    }
    return null;
  }

  function detectDetailView() {
    for (const selector of DETAIL_PANEL_SELECTORS) {
      for (const panel of document.querySelectorAll(selector)) {
        if (isVisiblyRendered(panel)) {
          detailViewState = {
            status: 'visible',
            source: 'visible-panel',
            checkedAt: Date.now()
          };
          return detailViewState;
        }
      }
    }

    const menuState = findActionLabelState();
    if (menuState) {
      detailViewState = { ...menuState, checkedAt: Date.now() };
      return detailViewState;
    }

    // A known detail-view container that exists but is not rendered is a useful
    // secondary indication that the view is currently hidden.
    const knownPanel = DETAIL_PANEL_SELECTORS.some(selector => document.querySelector(selector));
    detailViewState = {
      status: knownPanel ? 'hidden' : 'unknown',
      source: knownPanel ? 'hidden-panel' : 'none',
      checkedAt: Date.now()
    };
    return detailViewState;
  }

  function scheduleDetailDetection(delay = 100) {
    clearTimeout(detectionTimer);
    detectionTimer = setTimeout(detectDetailView, delay);
  }

  document.addEventListener('pointerdown', event => {
    if (event.button !== 0) return;

    const card = getCard(event.target);
    if (!card) {
      gesture = null;
      return;
    }

    gesture = {
      card,
      pointerId: event.pointerId,
      startX: event.clientX,
      startY: event.clientY,
      startedAt: performance.now(),
      moved: false,
      dragged: false
    };
  }, true);

  document.addEventListener('pointermove', event => {
    if (!gesture || event.pointerId !== gesture.pointerId) return;

    const dx = Math.abs(event.clientX - gesture.startX);
    const dy = Math.abs(event.clientY - gesture.startY);
    if (dx >= MOVE_THRESHOLD_PX || dy >= MOVE_THRESHOLD_PX) gesture.moved = true;

    if (
      gesture.card.classList.contains('ui-draggable-dragging') ||
      gesture.card.classList.contains('ghx-dragging') ||
      document.body.classList.contains('ghx-dragging')
    ) {
      gesture.dragged = true;
    }
  }, true);

  document.addEventListener('dragstart', event => {
    if (gesture && getCard(event.target) === gesture.card) gesture.dragged = true;
  }, true);

  function finishGesture(event) {
    if (!gesture || event.pointerId !== gesture.pointerId) return;

    lastGesture = {
      card: gesture.card,
      moved: gesture.moved,
      dragged: gesture.dragged,
      duration: performance.now() - gesture.startedAt,
      endedAt: performance.now()
    };
    gesture = null;
  }

  document.addEventListener('pointerup', finishGesture, true);
  document.addEventListener('pointercancel', event => {
    if (gesture && event.pointerId === gesture.pointerId) {
      gesture.dragged = true;
      finishGesture(event);
    }
  }, true);

  document.addEventListener('click', event => {
    if (!enabled || event.button !== 0 || event.defaultPrevented) return;

    const target = event.target instanceof Element ? event.target : null;
    const card = getCard(target);
    if (!target || !card || target.closest(IGNORE_SELECTOR)) return;

    const recent = lastGesture &&
      lastGesture.card === card &&
      performance.now() - lastGesture.endedAt < 800;

    if (!recent || lastGesture.moved || lastGesture.dragged || lastGesture.duration > HOLD_THRESHOLD_MS) {
      lastGesture = null;
      return;
    }

    lastGesture = null;
    const url = getIssueUrl(card);
    if (!url) return;

    event.preventDefault();
    event.stopPropagation();
    event.stopImmediatePropagation();

    chrome.runtime.sendMessage({ type: 'OPEN_TAB', url }).catch(() => {
      window.open(url, '_blank', 'noopener');
    });

    // Re-check after interaction. This catches a panel that was already open or
    // one that appears because another Jira handler still reacted to the event.
    scheduleDetailDetection(350);
  }, true);

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === 'DIAGNOSE') {
      const cards = document.querySelectorAll(CARD_SELECTOR);
      const detailView = detectDetailView();
      sendResponse({
        ok: true,
        enabled,
        cards: cards.length,
        sampleKey: cards[0]?.dataset.issueKey || null,
        detailView,
        url: location.href
      });
    }
  });

  const observer = new MutationObserver(() => scheduleDetailDetection(180));
  observer.observe(document.documentElement, {
    subtree: true,
    childList: true,
    attributes: true,
    attributeFilter: ['class', 'style', 'aria-hidden', 'aria-expanded', 'title', 'aria-label']
  });

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => scheduleDetailDetection(250), { once: true });
  } else {
    scheduleDetailDetection(100);
  }
})();
