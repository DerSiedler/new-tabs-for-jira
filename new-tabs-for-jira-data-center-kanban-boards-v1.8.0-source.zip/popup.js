'use strict';

const enabledInput = document.getElementById('enabled');
const foregroundInput = document.getElementById('openInForeground');
const languageInput = document.getElementById('language');
const switchLabel = document.getElementById('switchLabel');
const status = document.getElementById('status');
const details = document.getElementById('details');
const dot = document.getElementById('dot');
const behaviorHint = document.getElementById('behaviorHint');
const settings = document.getElementById('settings');
const enabledLabel = document.getElementById('enabledLabel');
const foregroundLabel = document.getElementById('foregroundLabel');
const detailViewBox = document.getElementById('detailViewBox');
const detailViewIcon = document.getElementById('detailViewIcon');
const detailViewTitle = document.getElementById('detailViewTitle');
const detailViewText = document.getElementById('detailViewText');

let messages = {};
let currentLanguage = 'en';

function browserLanguage() {
  const language = chrome.i18n.getUILanguage().toLowerCase();
  if (language.startsWith('de')) return 'de';
  if (language.startsWith('es')) return 'es';
  return 'en';
}

async function loadMessages(language) {
  const response = await fetch(chrome.runtime.getURL(`_locales/${language}/messages.json`));
  if (!response.ok) throw new Error(`Could not load locale: ${language}`);
  return response.json();
}

function t(key, substitutions = []) {
  const entry = messages[key];
  if (!entry?.message) return key;

  let text = entry.message;
  const values = Array.isArray(substitutions) ? substitutions : [substitutions];
  const placeholders = entry.placeholders || {};

  for (const [name, placeholder] of Object.entries(placeholders)) {
    const match = String(placeholder.content || '').match(/^\$(\d+)$/);
    const value = match ? values[Number(match[1]) - 1] ?? '' : '';
    text = text.replaceAll(`$${name.toUpperCase()}$`, String(value));
  }
  return text;
}

async function applyLanguage(preference) {
  currentLanguage = preference === 'auto' ? browserLanguage() : preference;
  messages = await loadMessages(currentLanguage);
  document.documentElement.lang = currentLanguage;

  document.querySelectorAll('[data-i18n]').forEach(element => {
    element.textContent = t(element.dataset.i18n);
  });

  document.title = t('extensionName');
  settings.setAttribute('aria-label', t('settingsLabel'));
  enabledLabel.setAttribute('aria-label', t('enableExtension'));
  foregroundLabel.setAttribute('aria-label', t('foregroundAria'));
  languageInput.setAttribute('aria-label', t('languageTitle'));
}

function setDot(state) {
  dot.className = `dot ${state}`;
}

function updateBehaviorHint(openInForeground) {
  behaviorHint.textContent = t(openInForeground ? 'hintForeground' : 'hintBackground');
}

function updateDetailView(state) {
  const statusValue = state?.status || 'unknown';
  detailViewBox.className = `requirement ${statusValue}`;

  if (statusValue === 'hidden') {
    detailViewIcon.textContent = '✓';
    detailViewTitle.textContent = t('detailViewHiddenTitle');
    detailViewText.textContent = t('detailViewHiddenText');
    return;
  }

  if (statusValue === 'visible') {
    detailViewIcon.textContent = '!';
    detailViewTitle.textContent = t('detailViewVisibleTitle');
    detailViewText.textContent = t('detailViewVisibleText');
    return;
  }

  if (statusValue === 'inactive') {
    detailViewIcon.textContent = '–';
    detailViewTitle.textContent = t('detailViewInactiveTitle');
    detailViewText.textContent = t('detailViewInactiveText');
    return;
  }

  detailViewIcon.textContent = '?';
  detailViewTitle.textContent = t('detailViewUnknownTitle');
  detailViewText.textContent = t('detailViewUnknownText');
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

async function refresh() {
  const preferences = await chrome.storage.local.get({
    enabled: true,
    openInForeground: true,
    uiLanguage: 'auto'
  });

  languageInput.value = preferences.uiLanguage;
  await applyLanguage(preferences.uiLanguage);

  enabledInput.checked = preferences.enabled;
  foregroundInput.checked = preferences.openInForeground;
  foregroundInput.disabled = !preferences.enabled;
  switchLabel.textContent = t(preferences.enabled ? 'enabled' : 'disabled');
  updateBehaviorHint(preferences.openInForeground);
  updateDetailView({ status: 'unknown' });

  if (!preferences.enabled) {
    status.textContent = t('statusDisabled');
    details.textContent = t('detailsDisabled');
    setDot('off');
    return;
  }

  const tab = await getActiveTab();
  if (!tab?.id) return;

  try {
    const result = await chrome.tabs.sendMessage(tab.id, { type: 'DIAGNOSE' });
    if (!result?.ok) throw new Error('No response');

    updateDetailView(result.detailView);

    if (result.cards > 0) {
      const cardWord = t(result.cards === 1 ? 'cardSingular' : 'cardPlural');
      const exampleText = result.sampleKey ? t('example', [result.sampleKey]) : '';
      status.textContent = t('statusReady');
      details.textContent = t('cardsDetected', [result.cards, cardWord, exampleText]);
      setDot('ok');
    } else {
      status.textContent = t('statusNoCards');
      details.textContent = t('detailsNoCards');
      setDot('warn');
    }
  } catch {
    status.textContent = t('statusInactive');
    details.textContent = t('detailsInactive');
    setDot('warn');
    updateDetailView({ status: 'inactive' });
  }
}

enabledInput.addEventListener('change', async () => {
  await chrome.storage.local.set({ enabled: enabledInput.checked });
  await refresh();
});

foregroundInput.addEventListener('change', async () => {
  await chrome.storage.local.set({ openInForeground: foregroundInput.checked });
  updateBehaviorHint(foregroundInput.checked);
});

languageInput.addEventListener('change', async () => {
  await chrome.storage.local.set({ uiLanguage: languageInput.value });
  await refresh();
});

refresh();
