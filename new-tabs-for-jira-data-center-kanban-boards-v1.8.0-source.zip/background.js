'use strict';

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.local.get(['enabled', 'openInForeground', 'uiLanguage']).then(result => {
    const defaults = {};
    if (typeof result.enabled !== 'boolean') defaults.enabled = true;
    if (typeof result.openInForeground !== 'boolean') defaults.openInForeground = true;
    if (!['auto', 'en', 'de'].includes(result.uiLanguage)) defaults.uiLanguage = 'auto';
    if (Object.keys(defaults).length) chrome.storage.local.set(defaults);
  });
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type !== 'OPEN_TAB' || typeof message.url !== 'string') return false;

  try {
    const url = new URL(message.url);
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Unsupported URL');

    chrome.storage.local.get({ openInForeground: true })
      .then(({ openInForeground }) => chrome.tabs.create({
        url: url.href,
        active: openInForeground !== false
      }))
      .then(() => sendResponse({ ok: true }))
      .catch(error => sendResponse({ ok: false, error: error.message }));
  } catch (error) {
    sendResponse({ ok: false, error: error.message });
  }
  return true;
});
